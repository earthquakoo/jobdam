SELECT_MENU_LIST = """Chatter
Daily conversation
Language
Sports
Music
Career
Study
Humor
Healing""".splitlines()